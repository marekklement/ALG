package alg;

import java.io.IOException;

/**
 * TODO describtion
 *
 * @author Marek Klement
 */
public class Main {
	public static void main(String[] args) throws IOException {
		FileReader rd = new FileReader();
		rd.read();
		rd.solving();
	}
}
