package alg;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * There is information about connections
 */
public class ConnectionDev {

	private List[] conns;
	private int edges;
	private int nodes;

	public ConnectionDev(int nodes, int edges, List[] conns){
		this.nodes = nodes;
		this.edges = edges;
		this.conns = conns;
	}

	List<Integer> lefts = new ArrayList<>();
	List<Integer> rights = new ArrayList<>();
	boolean[] wrongs;
	boolean[] solutions;

	public void solve(){
		int len = nodes+1;
		wrongs = new boolean[len];
		solutions = new boolean[len];
		//initArr();
		for (int i = 1; i<nodes;++i){
			if(conns[i].size()==2){
				//
				//System.out.println("Candidate: "+ i);
				wrongs[i]=true;
				solutions[i]=true;
				int left = (int) conns[i].get(0);
				int right = (int) conns[i].get(1);
				//
				//System.out.println("Left: " + left + " Right: " + right);
				lefts.add(left);
				rights.add(right);
				boolean endOfCycle = false;
				while(lefts.size()==rights.size()){
					lefts = addChidren(lefts);
					rights = addChidren(rights);
					int size = lefts.size();
					if(lefts.size() == 0){
						endOfCycle = true;
						break;
					}
					checkSame();
				}
				if(endOfCycle){
					break;
				} else {
					//initArr();
					wrongs = new boolean[len];
					solutions = new boolean[len];
					lefts.clear();
					rights.clear();
				}
			}
		}
	}

	public void printResult(){
		int solutionsCounter = 0;
		int size = solutions.length;
		int check = size-1;
		for(int i = 0; i<size;++i){
			if(solutions[i]){
				++solutionsCounter;
				if(solutionsCounter==100 || i==check)
					System.out.printf("%d",i);
				else
					System.out.printf("%d ",i);
			}
			if(solutionsCounter==100) break;
		}
	}

	private List<Integer> addChidren(List<Integer> children){
		//
		//System.out.println("ADDCHILDREN");
		List<Integer> newArr = new ArrayList<>();
		int size = children.size();
		for (int i=0;i<size;++i){
			int node = children.get(i);
			wrongs[node]=true;
			if (!solutions[node]){
				int size2 = conns[node].size();
				for (int j=0;j<size2;++j){
					int current = (int) conns[node].get(j);
					if(!wrongs[current] && !solutions[current]){
						//
						//System.out.println("Adding " + current + " into new arr");
						newArr.add(current);
					}
				}
			}
		}
		return newArr;
	}

	private void checkSame(){
		int size = lefts.size();
		for (int i = 0; i<size;++i){
			int current = lefts.get(i);
			if(rights.contains(current)){
				solutions[current] = true;
			}
		}
	}

	private void initArr(){
		for(int i = 0; i<=nodes;++i){
			wrongs[i]=false;
			solutions[i]=false;
		}
	}
}
