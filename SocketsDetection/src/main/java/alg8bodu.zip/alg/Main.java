package alg;

import java.io.IOException;
import java.time.Duration;

/**
 * Main class for solution
 * @author Marek Klement
 */
public class Main {
	public static void main(String[] args) throws IOException {

		//FileReader reader = new FileReader(args[0]);
		FileReader reader = new FileReader();
		ConnectionDev dev = reader.read();
//		long readTime = System.currentTimeMillis() - reader.start;
//		long st2 = System.currentTimeMillis();
		dev.solve();
		dev.printResult();
//		long elapsedTime = System.currentTimeMillis() - st2;
//		System.out.println();
//		System.out.println("Read time: "+readTime);
//		System.out.println("Find all: " +elapsedTime);
	}
}
