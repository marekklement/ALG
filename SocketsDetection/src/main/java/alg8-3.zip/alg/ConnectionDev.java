package alg;

import java.util.ArrayList;
import java.util.List;

/**
 * There is information about connections
 */
public class ConnectionDev {

	private List<Integer>[] conns;
	private int edges;
	private int nodes;

	public ConnectionDev(int nodes, int edges, List<Integer>[] conns){
		this.nodes = nodes;
		this.edges = edges;
		this.conns = conns;
	}

	List<Integer> lefts = new ArrayList<>();
	List<Integer> rights = new ArrayList<>();
	boolean[] wrongs;
	boolean[] solutions;

	public void solve(){
		int len = nodes+1;
		wrongs = new boolean[len];
		solutions = new boolean[len];
		for (int i = 1; i<nodes;++i){
			List<Integer> nod = conns[i];
			if(nod.size()==2){
				wrongs[i]=true;
				solutions[i]=true;
				int left = (int) nod.get(0);
				int right = (int) nod.get(1);
				lefts.add(left);
				rights.add(right);
				boolean endOfCycle = false;
				while(lefts.size()==rights.size()){
//					lefts = addChidren(lefts);
//					rights = addChidren(rights);
					addIT();
					int size = lefts.size();
					if(size!=rights.size()) break;
					if(size == 0){
						endOfCycle = true;
						break;
					}
					//checkSame();
				}
				if(endOfCycle){
					break;
				} else {
					wrongs = new boolean[len];
					solutions = new boolean[len];
					lefts = null;
					lefts = new ArrayList<>();
					rights = null;
					rights = new ArrayList<>();
				}
			}
		}
	}

	public void printResult(){
		int solutionsCounter = 0;
		int size = solutions.length;
		int check = size-1;
		for(int i = 0; i<size;++i){
			if(solutions[i]){
				++solutionsCounter;
				if(solutionsCounter==100 || i==check)
					System.out.printf("%d",i);
				else
					System.out.printf("%d ",i);
			}
			if(solutionsCounter==100) break;
		}
	}

//	private List<Integer> addChidren(List<Integer> children){
//		List<Integer> newArr = new ArrayList<>();
//		int size = children.size();
//		for (int i=0;i<size;++i){
//			int node = children.get(i);
//			List<Integer> nod = conns[node];
//			wrongs[node]=true;
//			if (!solutions[node]){
//				int size2 = nod.size();
//				for (int j=0;j<size2;++j){
//					int current = (int) nod.get(j);
//					if(!wrongs[current] && !solutions[current]){
//						newArr.add(current);
//					}
//				}
//			}
//		}
//		return newArr;
//	}

	private void addIT(){
		List<Integer> newArrLeft = new ArrayList<>();
		List<Integer> newArrRight = new ArrayList<>();
		int size = lefts.size();
		for (int i=0;i<size;++i){
			int nodeLF = lefts.get(i);
			int nodeRG = rights.get(i);
			List<Integer> nodLF = conns[nodeLF];
			List<Integer> nodRG = conns[nodeRG];
			wrongs[nodeLF]=true;
			wrongs[nodeRG]=true;
			int size2 = nodLF.size();
			for (int j=0;j<size2;++j){
				int current = (int) nodLF.get(j);
				if(!wrongs[current] && !solutions[current]){
					newArrLeft.add(current);
				}
				if(newArrRight.contains(current)){
					solutions[current] = true;
				}
			}

			size2 = nodRG.size();
			for (int j=0;j<size2;++j){
				int current = (int) nodRG.get(j);
				if(!wrongs[current] && !solutions[current]){
					newArrRight.add(current);
				}
				if(newArrLeft.contains(current)){
					solutions[current] = true;
				}
			}
		}
		lefts = newArrLeft;
		rights = newArrRight;
	}

	private void checkSame(){
		int size = lefts.size();
		for (int i = 0; i<size;++i){
			int current = lefts.get(i);
			if(rights.contains(current)){
				solutions[current] = true;
			}
		}
	}
}
